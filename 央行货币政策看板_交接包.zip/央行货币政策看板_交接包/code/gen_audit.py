#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
gen_audit.py — 五维度摘句审核看板（2026-07-22）
对全部保留文章重新提取摘句，按用户五维度组织：
  经济形势(=经济形势判断) / 货币政策取向 / 国债买卖 / 资金利率态度(=资金态度) / 债券市场态度
每条摘句可标记 对/不对，标记存 localStorage，可导出"不对"清单回贴给助手。
（"工作重点"维度已按用户指示逐条并轨：涉国债买卖→国债买卖，涉债市→债券市场态度，
  其余默认→货币政策取向，回顾/结构性/科普类删除；明细见 工作重点_合并方案.md）
"""

import json
import os
import re
import sys
from html import escape

sys.path.insert(0, '/mnt/agents/work/央行货币政策看板_融合版')
import extractor

CACHE = '/mnt/agents/work/央行货币政策看板_融合版/run_work/articles_cache.json'
REPORT = '/mnt/agents/work/央行货币政策看板_融合版/run_work/pipeline_report.json'
OUT = '/mnt/agents/work/央行货币政策看板_融合版/run_work/output/dim_audit.html'
MARKS = [
    '/mnt/agents/work/央行货币政策看板_融合版/run_work/user_marks_r3.txt',
    '/mnt/agents/work/央行货币政策看板_融合版/run_work/user_marks_r4.txt',
]


def _norm(s):
    return re.sub(r'\s+', '', s or '')


def load_user_marks():
    """解析用户审核导出的'不对'清单（2026-07-23 第三轮+第五轮）。
    返回 [(维度, 标题, 日期, 摘句)]。"""
    out = []
    for path in MARKS:
        if not os.path.exists(path):
            continue
        cur = None
        for line in open(path, encoding='utf-8'):
            line = line.strip()
            if not line:
                continue
            m = re.match(r'^【(.+?)】(.+?) \| (\d{4}-\d{2}-\d{2}) \| (.+)$', line)
            if m:
                cur = m.groups()
            else:
                mm = re.match(r'^([✗✓×✔])\s*(.+)$', line)
                if mm and cur:
                    out.append((cur[0], cur[1], cur[2], mm.group(2)))
    return out


# 直接谈论资金面的词表（用户：此类句从货币政策取向改归资金利率态度）
FUND_DIRECT = (r'(资金利率|资金面|dr00\d|回购利率|货币市场利率|隔夜|短端利率|'
               r'同业存单|资金价格|银行间.{0,4}流动性|流动性.{0,4}充裕|净投放|'
               r'净回笼|削峰填谷|呵护流动性|银行体系.{0,4}流动性|资金松紧|资金到期)')

USER_MARKS = load_user_marks()


def mark_match(dim, q):
    """看板摘句是否命中该维度的用户'不对'标记（宽松匹配，容忍……截断）"""
    nq = _norm(q).replace('……', '').replace('...', '')
    if not nq:
        return False
    for mdim, _t, _d, mq in USER_MARKS:
        if mdim != dim:
            continue
        nm = _norm(mq).replace('……', '').replace('...', '')
        if nm and (nm in nq or nq in nm):
            return mq
    return None

# 用户五维度 → 系统维度名
DIM_MAP = [
    ('经济形势', '经济形势判断'),
    ('货币政策取向', '货币政策取向'),
    ('国债买卖', '国债买卖'),
    ('资金利率态度', '资金态度'),
    ('债券市场态度', '债券市场态度'),
]
DIM_COLORS = {
    '经济形势': ('#e8f5e9', '#2e7d32'),
    '货币政策取向': ('#e3f2fd', '#1565c0'),
    '国债买卖': ('#fff3e0', '#e65100'),
    '资金利率态度': ('#f3e5f5', '#6a1b9a'),
    '债券市场态度': ('#fce4ec', '#ad1457'),
}

cache = json.load(open(CACHE, encoding='utf-8'))
report = json.load(open(REPORT, encoding='utf-8'))
kept_keys = {(k['title'], k['date']) for k in report['kept']}
# 标签以流水线报告为准（2026-07-23 修复：缓存 tag 字段陈旧，
# 曾致"暂停国债买卖"公告在审核页拿不到 is_major_gb_notice 而丢句）
tag_map = {(k['title'], k['date']): k.get('tag', '') for k in report['kept']}

# 逐篇重新提取，收集五维度摘句
dim_data = {u: [] for u, _ in DIM_MAP}   # 用户维度 -> [(句子, 文章信息)]
work_only_articles = []                  # 五维度无句、仅工作重点有句的文章
work_reassign = []                       # 工作重点并轨明细 [(摘句, 去向, 标题, 日期)]
r3_stats = {'del': {u: 0 for u, _ in DIM_MAP}, 'moved': 0, 'fund_dedup': 0}  # 第三轮统计
for a in cache:
    if (a.get('title'), a.get('date')) not in kept_keys:
        continue
    real_tag = tag_map.get((a.get('title'), a.get('date')), '') or a.get('tag', '')
    res = extractor.extract_core_view(
        a.get('content', ''), a.get('title', ''), real_tag,
        a.get('title_page'))
    info = {
        'date': f"{a['date'][:4]}-{a['date'][4:6]}-{a['date'][6:8]}",
        'title': a.get('title_page') or extractor.clean_title(a.get('title', '')),
        'link': a.get('link', ''),
        'tag': real_tag,
    }
    # 工作重点并轨（2026-07-23 用户指示）：逐条决定去向并并入目标维度
    for q in res.get('工作重点', []):
        if q == '/':
            continue
        target = extractor.reassign_work_focus(q)
        # 2026-07-23 第四轮：并轨到资金态度的句也要过"明确含义"门槛，
        # 不过的不再并入（纯操作量/取向表述类）
        if target == '资金态度' and not extractor.is_fund_meaningful(q):
            work_reassign.append((q, '【删除】', info['title'], info['date']))
            continue
        work_reassign.append((q, target or '【删除】', info['title'], info['date']))
        if target:
            res.setdefault(target, []).append(q)
    # === 2026-07-23 第三轮：应用用户"不对"标记（四维度定稿）===
    # 1) 经济形势/债券市场态度/国债买卖的✗ → 直接删除
    # 2) 货币政策取向的✗：含直接资金词的 → 改归资金利率态度
    #    （该文其它维度已摘此句时不再重复加入）；其余 → 删除
    r3_to_fund = []
    for udim, sdim in DIM_MAP:
        if sdim not in res:
            continue
        kept_q = []
        for q in res[sdim]:
            if q == '/':
                continue
            mq = mark_match(udim, q)
            if mq is None:
                kept_q.append(q)
                continue
            r3_stats['del'][udim] += 1
            if udim == '货币政策取向' and re.search(FUND_DIRECT, q, re.I) \
                    and extractor.is_fund_meaningful(q):
                r3_to_fund.append(q)
        res[sdim] = kept_q
    # 改归资金利率态度：须过文章内跨维度去重（用户：已摘入其它主题的不必再摘）
    for q in r3_to_fund:
        nq = _norm(q)
        dup = False
        for _udim, _sdim in DIM_MAP:
            if _udim == '资金利率态度':
                continue
            for o in res.get(_sdim, []):
                no = _norm(o)
                if o != '/' and (nq == no or (len(nq) >= 20 and len(no) >= 20
                                              and (nq in no or no in nq))):
                    dup = True
                    break
            if dup:
                break
        if not dup:
            res.setdefault('资金态度', []).append(q)
            r3_stats['moved'] += 1

    # 并轨+改归完成后，统一做一次文章内跨维度去重（2026-07-23 用户规则：
    # 同一篇文章的语句已摘入其它主题的，不再摘到资金利率态度。
    # extract 层去重发生在并轨之前，并轨句需在此兜底）
    if res.get('资金态度'):
        _others = []
        for _udim, _sdim in DIM_MAP:
            if _udim != '资金利率态度':
                _others.extend(_norm(o) for o in res.get(_sdim, []) if o != '/')
        if _others:
            _kept = []
            for q in res['资金态度']:
                if q == '/':
                    continue
                nq = _norm(q)
                if any(nq == no or (len(nq) >= 20 and len(no) >= 20
                                    and (nq in no or no in nq)) for no in _others):
                    r3_stats['fund_dedup'] += 1
                    continue
                _kept.append(q)
            res['资金态度'] = _kept

    has_any = False
    seen = set()
    for udim, sdim in DIM_MAP:
        for q in res.get(sdim, []):
            if q == '/' or (udim, q) in seen:
                continue
            seen.add((udim, q))
            dim_data[udim].append((q, info))
            has_any = True
    if not has_any:
        work_only_articles.append(info)

for u in dim_data:
    dim_data[u].sort(key=lambda x: x[1]['date'], reverse=True)
total = sum(len(v) for v in dim_data.values())

# ============ 生成 HTML ============
P = []
P.append('''<!DOCTYPE html><html><head><meta charset="UTF-8">
<title>五维度摘句审核</title>
<style>
body { font-family: "Microsoft YaHei","PingFang SC",sans-serif; margin:16px; background:#f5f5f5; }
h1 { font-size:20px; color:#333; margin:8px 0; }
.stats { background:#fff; padding:12px 18px; border-radius:8px; margin-bottom:12px; font-size:13px; line-height:1.9; }
.dimnav { position:sticky; top:0; background:#f5f5f5; padding:8px 0; z-index:10; }
.dimnav a { display:inline-block; padding:5px 14px; margin-right:6px; border-radius:16px; text-decoration:none; font-size:13px; font-weight:bold; }
.dimsec { margin-bottom:26px; }
.dimhead { font-size:16px; font-weight:bold; padding:8px 14px; border-radius:8px 8px 0 0; }
.art { background:#fff; border:1px solid #e3e3e3; border-top:none; }
.art-head { padding:8px 14px; background:#fafbfc; border-bottom:1px solid #eee; font-size:13px; }
.art-head a { color:#1a3a5c; font-weight:bold; text-decoration:none; }
.art-head a:hover { text-decoration:underline; }
.art-meta { color:#999; font-size:11px; margin-left:8px; }
.item { padding:8px 14px; border-bottom:1px solid #f2f2f2; font-size:13px; line-height:1.7; }
.item:last-child { border-bottom:none; }
.item .q { color:#222; }
.item .btns { margin-top:4px; }
.b { display:inline-block; padding:2px 12px; border-radius:3px; cursor:pointer; font-size:12px; margin-right:6px; border:1px solid #ccc; user-select:none; }
.b-ok { background:#e8f5e9; border-color:#4caf50; color:#2e7d32; }
.b-no { background:#ffebee; border-color:#f44336; color:#c62828; }
.item.ok { background:#f1f8f1; }
.item.no { background:#fff5f5; }
.item.ok .b-ok { background:#4caf50; color:#fff; }
.item.no .b-no { background:#f44336; color:#fff; }
.toolbar { margin:10px 0; }
.toolbar .b { font-size:13px; padding:5px 14px; background:#fff; }
#export { width:100%; height:130px; font-size:12px; margin-top:8px; display:none; }
.counter { color:#888; font-weight:normal; font-size:12px; margin-left:10px; }
details { background:#fff; border-radius:8px; padding:8px 14px; margin-bottom:14px; font-size:13px; }
summary { cursor:pointer; font-weight:bold; }
</style></head><body>''')

P.append('<h1>五维度摘句审核看板</h1>')
stat_cells = ''.join(
    f'<span style="background:{DIM_COLORS[u][0]};color:{DIM_COLORS[u][1]};'
    f'padding:2px 10px;border-radius:10px;margin-right:8px;font-weight:bold">'
    f'{u} {len(dim_data[u])}条</span>' for u, _ in DIM_MAP)
P.append(f'<div class="stats">{stat_cells}<br>'
         f'共 {len(kept_keys)} 篇保留文章，五维度摘句合计 {total} 条；'
         f'其中 {len(work_only_articles)} 篇五维度无摘句（见文末）。'
         f'"工作重点"维度已并轨：{len(work_reassign)} 条摘句逐条归入五维度或删除（明细见合并方案）。'
         f'<br><b>第三轮已定稿应用（2026-07-23）：</b>'
         f'按你的「不对」标记删除 {sum(r3_stats["del"].values())} 条'
         f'（经济形势{r3_stats["del"]["经济形势"]}、货币政策取向{r3_stats["del"]["货币政策取向"]}、'
         f'债券市场态度{r3_stats["del"]["债券市场态度"]}），'
         f'其中 {r3_stats["moved"]} 条直接谈资金面的句子已改归资金利率态度；'
         f'同一篇文章内已摘入其它维度的语句不再重复摘入资金利率态度'
         f'（本次去重 {r3_stats["fund_dedup"]} 条）。'
         f'<br><b>第四轮资金利率态度收紧（2026-07-23）：</b>'
         f'只摘有明确含义的信息——DR001/DR007 等具体利率数值与变动、'
         r'与政策利率的位置关系（围绕/偏离/上破/下破）、明确的松紧判断；'
         f'纯加量减量操作叙述、适度宽松等取向表述、机制科普不再摘。'
         f'<br>操作：逐条点「对」或「不对」，标记自动保存在浏览器；'
         f'审完点「导出不对清单」把文本贴回给我即可。</div>')

P.append('<div class="dimnav">' + ''.join(
    f'<a href="#dim-{i}" style="background:{DIM_COLORS[u][0]};color:{DIM_COLORS[u][1]}">'
    f'{u} ({len(dim_data[u])})</a>' for i, (u, _) in enumerate(DIM_MAP)) + '</div>')

P.append('''<div class="toolbar">
<span class="b" onclick="markVisible('ok')">本页全标对</span>
<span class="b" onclick="markVisible('no')">本页全标不对</span>
<span class="b" onclick="exportNo()">导出不对清单</span>
<span class="b" onclick="resetAll()">清空标记</span>
<span class="counter" id="cnt"></span>
</div>
<textarea id="export" readonly></textarea>''')

for di, (udim, _) in enumerate(DIM_MAP):
    bg, fg = DIM_COLORS[udim]
    items = dim_data[udim]
    P.append(f'<div class="dimsec" id="dim-{di}">')
    P.append(f'<div class="dimhead" style="background:{bg};color:{fg}">{udim}（{len(items)}条）</div>')
    # 按文章分组
    cur = None
    for qi, (q, info) in enumerate(items):
        key = (info['title'], info['date'])
        if key != cur:
            if cur is not None:
                P.append('</div>')
            cur = key
            P.append('<div class="art">')
            P.append(f'<div class="art-head"><a href="{escape(info["link"])}" target="_blank">'
                     f'{escape(info["title"])}</a>'
                     f'<span class="art-meta">{info["date"]} | {escape(info["tag"])}</span></div>')
        iid = f'd{di}-{qi}'
        P.append(f'<div class="item" id="{iid}"><div class="q">{escape(q)}</div>'
                 f'<div class="btns"><span class="b b-ok" onclick="mark(\'{iid}\',\'ok\',event)">对</span>'
                 f'<span class="b b-no" onclick="mark(\'{iid}\',\'no\',event)">不对</span></div></div>')
    if cur is not None:
        P.append('</div>')
    P.append('</div>')

# 五维度无摘句文章清单
P.append(f'<details><summary>五维度无摘句的文章（{len(work_only_articles)}篇）</summary>')
for info in work_only_articles:
    P.append(f'<div style="padding:3px 0"><a href="{escape(info["link"])}" target="_blank">{escape(info["title"])}</a>'
             f'<span class="art-meta">{info["date"]} | {escape(info["tag"])}</span></div>')
P.append('</details>')

P.append('''<script>
const KEY = 'dim_audit_marks_v3';
let marks = JSON.parse(localStorage.getItem(KEY) || '{}');
function apply() {
  for (const [id, st] of Object.entries(marks)) {
    const el = document.getElementById(id);
    if (el) { el.classList.remove('ok','no'); el.classList.add(st); }
  }
  updateCnt();
}
function mark(id, st, ev) {
  ev.stopPropagation();
  const el = document.getElementById(id);
  if (marks[id] === st) { delete marks[id]; el.classList.remove('ok','no'); }
  else { marks[id] = st; el.classList.remove('ok','no'); el.classList.add(st); }
  localStorage.setItem(KEY, JSON.stringify(marks));
  updateCnt();
}
function markVisible(st) {
  document.querySelectorAll('.item').forEach(el => {
    marks[el.id] = st; el.classList.remove('ok','no'); el.classList.add(st);
  });
  localStorage.setItem(KEY, JSON.stringify(marks));
  updateCnt();
}
function resetAll() {
  if (!confirm('清空全部标记？')) return;
  marks = {}; localStorage.removeItem(KEY);
  document.querySelectorAll('.item').forEach(el => el.classList.remove('ok','no'));
  updateCnt();
}
function updateCnt() {
  const ok = Object.values(marks).filter(v=>v==='ok').length;
  const no = Object.values(marks).filter(v=>v==='no').length;
  document.getElementById('cnt').textContent = `已标 对${ok} / 不对${no} / 共${document.querySelectorAll('.item').length}`;
}
function exportNo() {
  const lines = [];
  document.querySelectorAll('.dimsec').forEach(sec => {
    const dim = sec.querySelector('.dimhead').textContent.replace(/（.*$/,'');
    sec.querySelectorAll('.art').forEach(art => {
      const title = art.querySelector('.art-head a').textContent;
      const meta = art.querySelector('.art-meta').textContent;
      art.querySelectorAll('.item.no').forEach(it => {
        lines.push(`【${dim}】${title} | ${meta}\\n  ✗ ${it.querySelector('.q').textContent}`);
      });
    });
  });
  const ta = document.getElementById('export');
  ta.style.display = 'block';
  ta.value = lines.length ? lines.join('\\n') : '（没有标记"不对"的摘句）';
  ta.scrollIntoView();
}
apply();
</script></body></html>''')

with open(OUT, 'w', encoding='utf-8') as f:
    f.write('\n'.join(P))
print(f'审核看板已生成: {OUT}')
print(f'五维度摘句: {total} 条')
for u, _ in DIM_MAP:
    print(f'  {u}: {len(dim_data[u])} 条')
print(f'五维度无摘句文章: {len(work_only_articles)} 篇')

# ============ 工作重点并轨方案（2026-07-23 用户任务二） ============
MD = '/mnt/agents/work/央行货币政策看板_融合版/run_work/工作重点_合并方案.md'
groups = {}
for q, target, t, d in work_reassign:
    groups.setdefault(target, []).append((q, t, d))
L = []
L.append('# "工作重点"维度摘句并轨方案\n')
L.append(f'共 {len(work_reassign)} 条摘句，逐条去向如下（按目标维度分组）。\n')
L.append('## 汇总\n')
L.append('| 去向 | 条数 |')
L.append('| --- | --- |')
for g in ['货币政策取向', '国债买卖', '债券市场态度', '经济形势判断', '资金态度', '【删除】']:
    if g in groups:
        L.append(f'| {g} | {len(groups[g])} |')
L.append('')
for g in ['货币政策取向', '国债买卖', '债券市场态度', '经济形势判断', '资金态度', '【删除】']:
    if g not in groups:
        continue
    L.append(f'## → {g}（{len(groups[g])}条）\n')
    for q, t, d in groups[g]:
        L.append(f'- {d}《{t}》\n  > {q}')
    L.append('')
with open(MD, 'w', encoding='utf-8') as f:
    f.write('\n'.join(L))
print(f'并轨方案已生成: {MD}（工作重点摘句 {len(work_reassign)} 条）')
for g in ['货币政策取向', '国债买卖', '债券市场态度', '经济形势判断', '资金态度', '【删除】']:
    if g in groups:
        print(f'  → {g}: {len(groups[g])} 条')
