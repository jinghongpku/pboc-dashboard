#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
gen_final.py — 最终成品看板（2026-07-23）
五维度定稿摘句展示：经济形势 / 货币政策取向 / 国债买卖 / 资金利率态度 / 债券市场态度
数据逻辑与审核看板（gen_audit.py）完全一致：
  提取 → 工作重点并轨 → 用户删除清单(r3+r4) → 资金句改归 → 文章内跨维度去重
视觉：现代化金融仪表盘风格（渐变hero / 维度色卡 / 搜索过滤 / sticky导航）
"""

import json
import os
import re
import sys
from html import escape

sys.path.insert(0, '/mnt/agents/work/央行货币政策看板_融合版')
import extractor

CACHE = '/mnt/agents/work/央行货币政策看板_融合版/run_work/articles_cache.json'
REPORT = '/mnt/agents/work/央行货币政策看板_融合版/run_work/pipeline_report.json'
OUT = '/mnt/agents/work/央行货币政策看板_融合版/run_work/output/final_dashboard.html'
MARKS = [
    '/mnt/agents/work/央行货币政策看板_融合版/run_work/user_marks_r3.txt',
    '/mnt/agents/work/央行货币政策看板_融合版/run_work/user_marks_r4.txt',
]

DIM_MAP = [
    ('经济形势', '经济形势判断'),
    ('货币政策取向', '货币政策取向'),
    ('国债买卖', '国债买卖'),
    ('资金利率态度', '资金态度'),
    ('债券市场态度', '债券市场态度'),
]
DIM_STYLE = {
    '经济形势':   {'c': '#0f9d58', 'bg': '#e6f4ea', 'icon': 'M3 17l6-6 4 4 8-8', 'en': 'ECONOMY'},
    '货币政策取向': {'c': '#1a73e8', 'bg': '#e8f0fe', 'icon': 'M12 2v20M2 12h20', 'en': 'POLICY STANCE'},
    '国债买卖':   {'c': '#e8710a', 'bg': '#fef3e6', 'icon': 'M4 20V10M10 20V4M16 20v-8M22 20H2', 'en': 'BOND TRADING'},
    '资金利率态度': {'c': '#9334e6', 'bg': '#f3e8fd', 'icon': 'M2 12c3-6 6 6 9 0s6 6 9 0', 'en': 'LIQUIDITY & RATES'},
    '债券市场态度': {'c': '#d93025', 'bg': '#fce8e6', 'icon': 'M3 12l4-8 4 12 4-16 4 12 2-4h2', 'en': 'BOND MARKET'},
}


def _norm(s):
    return re.sub(r'\s+', '', s or '')


def load_user_marks():
    out = []
    for path in MARKS:
        if not os.path.exists(path):
            continue
        cur = None
        for line in open(path, encoding='utf-8'):
            line = line.strip()
            if not line:
                continue
            m = re.match(r'^【(.+?)】(.+?) \| (\d{4}-\d{2}-\d{2}) \| (.+)$', line)
            if m:
                cur = m.groups()
            else:
                mm = re.match(r'^([✗✓×✔])\s*(.+)$', line)
                if mm and cur:
                    out.append((cur[0], cur[1], cur[2], mm.group(2)))
    return out


FUND_DIRECT = (r'(资金利率|资金面|dr00\d|回购利率|货币市场利率|隔夜|短端利率|'
               r'同业存单|资金价格|银行间.{0,4}流动性|流动性.{0,4}充裕|净投放|'
               r'净回笼|削峰填谷|呵护流动性|银行体系.{0,4}流动性|资金松紧|资金到期)')

USER_MARKS = load_user_marks()


def mark_match(dim, q):
    nq = _norm(q).replace('……', '').replace('...', '')
    if not nq:
        return False
    for mdim, _t, _d, mq in USER_MARKS:
        if mdim != dim:
            continue
        nm = _norm(mq).replace('……', '').replace('...', '')
        if nm and (nm in nq or nq in nm):
            return mq
    return None


# ================= 数据收集（与 gen_audit.py 一致） =================
cache = json.load(open(CACHE, encoding='utf-8'))
report = json.load(open(REPORT, encoding='utf-8'))
kept_keys = {(k['title'], k['date']) for k in report['kept']}
tag_map = {(k['title'], k['date']): k.get('tag', '') for k in report['kept']}

dim_data = {u: [] for u, _ in DIM_MAP}
for a in cache:
    if (a.get('title'), a.get('date')) not in kept_keys:
        continue
    real_tag = tag_map.get((a.get('title'), a.get('date')), '') or a.get('tag', '')
    res = extractor.extract_core_view(
        a.get('content', ''), a.get('title', ''), real_tag, a.get('title_page'))
    info = {
        'date': f"{a['date'][:4]}-{a['date'][4:6]}-{a['date'][6:8]}",
        'title': a.get('title_page') or extractor.clean_title(a.get('title', '')),
        'link': a.get('link', ''),
        'tag': real_tag,
    }
    for q in res.get('工作重点', []):
        if q == '/':
            continue
        target = extractor.reassign_work_focus(q)
        if target == '资金态度' and not extractor.is_fund_meaningful(q):
            continue
        if target:
            res.setdefault(target, []).append(q)
    r3_to_fund = []
    for udim, sdim in DIM_MAP:
        if sdim not in res:
            continue
        kept_q = []
        for q in res[sdim]:
            if q == '/':
                continue
            if mark_match(udim, q) is None:
                kept_q.append(q)
                continue
            if udim == '货币政策取向' and re.search(FUND_DIRECT, q, re.I) \
                    and extractor.is_fund_meaningful(q):
                r3_to_fund.append(q)
        res[sdim] = kept_q
    for q in r3_to_fund:
        nq = _norm(q)
        dup = False
        for _udim, _sdim in DIM_MAP:
            if _udim == '资金利率态度':
                continue
            for o in res.get(_sdim, []):
                no = _norm(o)
                if o != '/' and (nq == no or (len(nq) >= 20 and len(no) >= 20
                                              and (nq in no or no in nq))):
                    dup = True
                    break
            if dup:
                break
        if not dup:
            res.setdefault('资金态度', []).append(q)
    if res.get('资金态度'):
        _others = []
        for _udim, _sdim in DIM_MAP:
            if _udim != '资金利率态度':
                _others.extend(_norm(o) for o in res.get(_sdim, []) if o != '/')
        if _others:
            res['资金态度'] = [
                q for q in res['资金态度']
                if q != '/' and not any(
                    _norm(q) == no or (len(_norm(q)) >= 20 and len(no) >= 20
                                       and (_norm(q) in no or no in _norm(q)))
                    for no in _others)]
    seen = set()
    for udim, sdim in DIM_MAP:
        for q in res.get(sdim, []):
            if q == '/' or (udim, q) in seen:
                continue
            seen.add((udim, q))
            dim_data[udim].append((q, info))

for u in dim_data:
    dim_data[u].sort(key=lambda x: x[1]['date'], reverse=True)
total = sum(len(v) for v in dim_data.values())

# ================= 渲染 =================
P = []
P.append('''<!DOCTYPE html><html lang="zh-CN"><head><meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>央行货币政策跟踪看板</title>
<style>
:root {
  --ink: #1b2a41; --sub: #5b6b82; --line: #e8edf4; --bg: #f4f7fb;
}
* { box-sizing: border-box; margin: 0; padding: 0; }
body { font-family: "PingFang SC","Microsoft YaHei","Noto Sans CJK SC",sans-serif;
       background: var(--bg); color: var(--ink); }
.hero {
  background: linear-gradient(135deg, #0b2149 0%, #123a7a 55%, #1a5fb4 100%);
  color: #fff; padding: 44px 24px 88px; position: relative; overflow: hidden;
}
.hero::after {
  content: ""; position: absolute; right: -120px; top: -120px; width: 420px; height: 420px;
  background: radial-gradient(circle, rgba(255,255,255,.14), transparent 65%); border-radius: 50%;
}
.hero::before {
  content: ""; position: absolute; left: -80px; bottom: -160px; width: 340px; height: 340px;
  background: radial-gradient(circle, rgba(120,180,255,.18), transparent 65%); border-radius: 50%;
}
.hero-inner { max-width: 1080px; margin: 0 auto; position: relative; z-index: 1; }
.hero h1 { font-size: 30px; letter-spacing: 2px; font-weight: 700; }
.hero h1 .thin { font-weight: 300; opacity: .85; }
.hero .sub { margin-top: 10px; font-size: 13.5px; color: #b9cff0; letter-spacing: .5px; }
.hero .sub b { color: #ffd98a; font-weight: 600; }
.statrow { max-width: 1080px; margin: -56px auto 0; padding: 0 24px;
  display: grid; grid-template-columns: repeat(5, 1fr); gap: 14px; position: relative; z-index: 2; }
.stat {
  background: rgba(255,255,255,.96); border-radius: 14px; padding: 16px 16px 14px;
  box-shadow: 0 8px 24px rgba(15,40,90,.12); cursor: pointer;
  border-top: 3px solid var(--dc); transition: transform .15s ease, box-shadow .15s ease;
  text-decoration: none; display: block;
}
.stat:hover { transform: translateY(-3px); box-shadow: 0 14px 30px rgba(15,40,90,.18); }
.stat .n { font-size: 28px; font-weight: 700; color: var(--dc); line-height: 1.1; }
.stat .l { font-size: 13px; font-weight: 600; margin-top: 5px; }
.stat .e { font-size: 10px; color: #9aa8bc; letter-spacing: 1px; margin-top: 2px; }
.toolbar {
  position: sticky; top: 0; z-index: 20; background: rgba(244,247,251,.92);
  backdrop-filter: blur(8px); padding: 12px 24px; border-bottom: 1px solid var(--line);
}
.toolbar-inner { max-width: 1080px; margin: 0 auto; display: flex; align-items: center; gap: 10px; flex-wrap: wrap; }
.chip {
  font-size: 12.5px; padding: 5px 13px; border-radius: 999px; text-decoration: none;
  background: #fff; color: var(--sub); border: 1px solid var(--line); font-weight: 600;
  transition: all .15s ease;
}
.chip:hover { border-color: var(--dc); color: var(--dc); }
.search {
  margin-left: auto; border: 1px solid var(--line); border-radius: 999px; padding: 7px 16px;
  font-size: 13px; width: 220px; outline: none; background: #fff; color: var(--ink);
}
.search:focus { border-color: #1a5fb4; box-shadow: 0 0 0 3px rgba(26,95,180,.12); }
main { max-width: 1080px; margin: 0 auto; padding: 10px 24px 60px; }
.dimsec { margin-top: 34px; }
.dimhead {
  display: flex; align-items: center; gap: 12px; padding: 13px 18px; border-radius: 14px;
  background: var(--dbg); margin-bottom: 14px;
}
.dimhead svg { width: 22px; height: 22px; stroke: var(--dc); fill: none; stroke-width: 2; stroke-linecap: round; stroke-linejoin: round; }
.dimhead .name { font-size: 17px; font-weight: 700; color: var(--dc); }
.dimhead .en { font-size: 10.5px; color: #9aa8bc; letter-spacing: 1.5px; }
.dimhead .cnt { margin-left: auto; font-size: 13px; font-weight: 700; color: var(--dc);
  background: #fff; padding: 3px 12px; border-radius: 999px; }
.art {
  background: #fff; border-radius: 14px; margin-bottom: 12px; overflow: hidden;
  box-shadow: 0 2px 10px rgba(15,40,90,.06); border: 1px solid #eef2f8;
  transition: box-shadow .15s ease;
}
.art:hover { box-shadow: 0 6px 20px rgba(15,40,90,.11); }
.art-head { padding: 13px 18px 10px; display: flex; align-items: baseline; gap: 10px; flex-wrap: wrap; }
.art-head a { color: var(--ink); font-weight: 700; font-size: 14.5px; text-decoration: none; }
.art-head a:hover { color: #1a5fb4; }
.badge { font-size: 11px; color: var(--sub); background: var(--bg); padding: 2px 10px; border-radius: 999px; }
.badge.date { font-variant-numeric: tabular-nums; }
.art-head .src { margin-left: auto; font-size: 11px; color: #a5b2c5; }
.q { padding: 9px 18px 9px 20px; font-size: 13.5px; line-height: 1.85; color: #2c3e57;
  border-top: 1px dashed #edf1f7; position: relative; }
.q::before { content: ""; position: absolute; left: 0; top: 0; bottom: 0; width: 3px; background: var(--dc); opacity: .55; }
.q:first-of-type { border-top: none; }
footer { text-align: center; color: #9aa8bc; font-size: 12px; padding: 30px 0 40px; line-height: 2; }
.hidden { display: none !important; }
@media (max-width: 760px) {
  .statrow { grid-template-columns: repeat(2, 1fr); }
  .search { width: 100%; margin-left: 0; }
}
</style></head><body>''')

P.append(f'''<div class="hero"><div class="hero-inner">
<h1>央行货币政策跟踪看板 <span class="thin">PBOC POLICY TRACKER</span></h1>
<div class="sub">数据源：金融时报 / 中国金融新闻网 · 记者马梅若、马玲 · 保留文章 <b>{len(kept_keys)}</b> 篇 · 五维度定稿摘句 <b>{total}</b> 条 · 更新至 2026-07-23</div>
</div></div>''')

P.append('<div class="statrow">')
for i, (u, _) in enumerate(DIM_MAP):
    st = DIM_STYLE[u]
    P.append(f'<a class="stat" href="#dim-{i}" style="--dc:{st["c"]}">'
             f'<div class="n">{len(dim_data[u])}</div>'
             f'<div class="l">{u}</div><div class="e">{st["en"]}</div></a>')
P.append('</div>')

P.append('<div class="toolbar"><div class="toolbar-inner">')
for i, (u, _) in enumerate(DIM_MAP):
    P.append(f'<a class="chip" href="#dim-{i}" style="--dc:{DIM_STYLE[u]["c"]}">{u}</a>')
P.append('<input class="search" id="kw" placeholder="搜索摘句 / 文章标题…" oninput="filt()">')
P.append('</div></div><main>')

for di, (udim, _) in enumerate(DIM_MAP):
    st = DIM_STYLE[udim]
    P.append(f'<section class="dimsec" id="dim-{di}" style="--dc:{st["c"]};--dbg:{st["bg"]}">')
    P.append(f'<div class="dimhead"><svg viewBox="0 0 24 24"><path d="{st["icon"]}"/></svg>'
             f'<span class="name">{udim}</span><span class="en">{st["en"]}</span>'
             f'<span class="cnt">{len(dim_data[udim])} 条</span></div>')
    cur = None
    for q, info in dim_data[udim]:
        key = (info['title'], info['date'])
        if key != cur:
            if cur is not None:
                P.append('</div>')
            cur = key
            P.append(f'<div class="art" data-t="{escape(info["title"].lower())}">')
            P.append(f'<div class="art-head"><a href="{escape(info["link"])}" target="_blank">'
                     f'{escape(info["title"])}</a>'
                     f'<span class="badge date">{info["date"]}</span>'
                     f'<span class="badge">{escape(info["tag"])}</span></div>')
        P.append(f'<div class="q">{escape(q)}</div>')
    if cur is not None:
        P.append('</div>')
    P.append('</section>')

P.append('</main>')
P.append(f'''<footer>央行货币政策跟踪看板 · 五维度定稿版（经五轮审核）<br>
共 {len(kept_keys)} 篇保留文章 · {total} 条摘句 · 生成于 2026-07-23</footer>''')

P.append('''<script>
function filt() {
  const kw = document.getElementById('kw').value.trim().toLowerCase();
  document.querySelectorAll('.art').forEach(el => {
    if (!kw) { el.classList.remove('hidden'); return; }
    el.classList.toggle('hidden', !el.textContent.toLowerCase().includes(kw));
  });
  document.querySelectorAll('.dimsec').forEach(sec => {
    const any = sec.querySelector('.art:not(.hidden)');
    sec.classList.toggle('hidden', !any);
  });
}
document.querySelectorAll('a[href^="#dim-"]').forEach(a => {
  a.addEventListener('click', e => {
    e.preventDefault();
    const t = document.querySelector(a.getAttribute('href'));
    if (t) window.scrollTo({ top: t.getBoundingClientRect().top + window.scrollY - 64, behavior: 'smooth' });
  });
});
</script></body></html>''')

open(OUT, 'w', encoding='utf-8').write('\n'.join(P))
print(f'最终看板已生成: {OUT}')
print(f'五维度摘句: {total} 条')
for u, _ in DIM_MAP:
    print(f'  {u}: {len(dim_data[u])} 条')
